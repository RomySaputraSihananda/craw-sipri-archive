from archive import Archive

if(__name__ == '__main__'):
    archive: Archive = Archive()
    archive.execute() 